<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Login with Facebook in CodeIgniter</title>
</head>
<body>
	<a href="<?=$authUrl?>"><img src="<?=base_url()?>img/flogin.png" alt=""/></a>
</body>
</html>